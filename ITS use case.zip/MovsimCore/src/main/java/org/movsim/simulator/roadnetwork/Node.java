package org.movsim.simulator.roadnetwork;

public interface Node {

    boolean hasId();

    long getId();

    void setId(long id);
}

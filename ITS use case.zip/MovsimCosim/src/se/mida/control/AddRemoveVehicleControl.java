package se.mida.control;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import mecsyco.core.type.Tuple2;
import peersim.config.Configuration;
import peersim.core.*;
import peersim.dynamics.NodeInitializer;
import se.mida.entity.VanetNode;
import se.mida.mecsyco.PeersimModelArtifact;

public class AddRemoveVehicleControl implements Control {

	// --------------------------------------------------------------------------
	// Parameters
	// --------------------------------------------------------------------------

	/**
	 * Config parameter which gives the prefix of node initializers. An arbitrary
	 * number of node initializers can be specified (Along with their parameters).
	 * These will be applied
	 * on the newly created nodes. The initializers are ordered according to
	 * alphabetical order if their ID.
	 * Example:
	 * <pre>
	control.0 DynamicNetwork
	control.0.init.0 RandNI
	control.0.init.0.k 5
	control.0.init.0.protocol somelinkable
	...
	 * </pre>
	 * @config
	 */
	private static final String PAR_INIT = "init";

	// --------------------------------------------------------------------------
	// Fields
	// --------------------------------------------------------------------------

	/** node initializers to apply on the newly added nodes */
	protected final NodeInitializer[] inits;

	// vehicle to add
	private static Map<Long, String> addVehicles;

	// vehicle to remove
	private static List<Long> removeVehicles;

	// --------------------------------------------------------------------------
	// Protected methods
	// --------------------------------------------------------------------------

	protected void add() {

		Iterator it = addVehicles.entrySet().iterator();
		while (it.hasNext()) {

			Node newnode = (Node) Network.prototype.clone();
			for (int j = 0; j < inits.length; ++j) {
				inits[j].initialize(newnode);
			}
			// it is not necessary to update vehicle's position. The next control class will update it.		
			Network.add(newnode);

			Map.Entry pair = (Map.Entry) it.next();
			// Set id
			((VanetNode) newnode).setVehicleID((long) pair.getKey());
			// Set label
			((VanetNode) newnode).setLabel((String) pair.getValue());

			SimulationObserver.incrementNumberOfVehiclesJoined();
			
			it.remove();
			// System.out.println("Appena entrato veicolo:"+((VanetNode)newnode).getVehicleID()+" label:"+((VanetNode)newnode).getLabel()+" at:"+CommonState.getTime()/1000.0+" Network size:"+Network.size());
		}

	}

	protected void remove() {

		for (Long vehicleId : removeVehicles) {
			VanetNode nodeToRemove = VanetNode.getVanetNode(vehicleId);
			// set distance to infinity. This allows VanetProtocol to remove neighbor nodes by distance
			nodeToRemove.setX(Double.MAX_VALUE);
			nodeToRemove.setY(Double.MAX_VALUE);
			// always use index and not id to remove nodes
			VanetNode n = (VanetNode) Network.remove(nodeToRemove.getIndex());
			//			System.out.println("Nodo rimosso "+n.getVehicleID()+" time "+CommonState.getTime()/1000.0+"  Dimensione rete:"+Network.size());
			//			VanetNode.printNetwork();
		}

		setRemoveVehicles(null);
	}

	// --------------------------------------------------------------------------
	// Initialization
	// --------------------------------------------------------------------------

	/**
	 * Standard constructor that reads the configuration parameters.
	 * Invoked by the simulation engine.
	 * @param prefix the configuration prefix for this class
	 */
	public AddRemoveVehicleControl(String prefix) {
		Object[] tmp = Configuration.getInstanceArray(prefix + "." + PAR_INIT);
		inits = new NodeInitializer[tmp.length];
		for (int i = 0; i < tmp.length; ++i) {
			//System.out.println("Inits " + tmp[i]);
			inits[i] = (NodeInitializer) tmp[i];
		}
		addVehicles = null;
		removeVehicles = null;
	}

	public static List<Long> getRemoveVehicles() {
		return removeVehicles;
	}

	public static void setRemoveVehicles(List<Long> list) {
		AddRemoveVehicleControl.removeVehicles = list;
	}

	public static Map<Long, String> getAddVehicles() {
		return addVehicles;
	}

	public static void setAddVehicles(Map<Long, String> addVehicles) {
		AddRemoveVehicleControl.addVehicles = addVehicles;
	}

	@Override
	public boolean execute() {
//		System.out.println("Add/remove control " + CommonState.getTime() / 1000.0);
		// add VenetNode
		if (addVehicles != null && !addVehicles.isEmpty()) {
			add();
		}
		// remove multiple VanetNode
		if (removeVehicles != null && !removeVehicles.isEmpty()) {
			remove();
		}
		return false;
	}

}

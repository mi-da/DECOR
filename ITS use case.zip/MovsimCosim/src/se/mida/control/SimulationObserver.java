package se.mida.control;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import peersim.core.Control;
import peersim.edsim.EDSimulator;

public class SimulationObserver implements Control {

	private String name;
	private static int numberOfSentMessages = 0;
	private static int numberOfVehiclesJoined = 0;
	
	private static DescriptiveStatistics adaptationTimes;

	public SimulationObserver(String name) {
		this.name = name;
		adaptationTimes = new DescriptiveStatistics();
	}

	@Override
	public boolean execute() {
		
		System.out.println("Simulation Observer "+EDSimulator.getCurrentSimulationTime());

		// new output file
		FileOutputStream fos;
		PrintStream ps;
		
		try {
			fos = new FileOutputStream("Observer.txt");
			ps = new PrintStream(fos);
			ps.println("numberOfVehiclesJoined "+numberOfVehiclesJoined);
			ps.println("numberOfSentMessages "+numberOfSentMessages);
			ps.println("averageMessagesPerVehicle "+((double)numberOfSentMessages/(double)numberOfVehiclesJoined));
			ps.println("adaptationTimeMeans "+adaptationTimes.getMean());
			ps.println("adaptationTimeSTD "+adaptationTimes.getStandardDeviation());
					
//			ps.println("Adaptation Times "+adaptationTimes.toString());
	
			ps.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Output file generato!");
		return false;
	}

	public static void incrementNumberOfSentMess() {
		numberOfSentMessages++;
	}
	
	public static void incrementNumberOfVehiclesJoined() {
		numberOfVehiclesJoined++;
	}
	
	public static void addAdaptationTime(double adaptationTime) {
		adaptationTimes.addValue(adaptationTime);
	}
}

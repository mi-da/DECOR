package se.mida.control;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import mecsyco.core.type.Tuple2;
import mecsyco.core.type.Tuple3;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import se.mida.entity.VanetNode;

public class VehiclePositionControl implements Control {

	private static Map<Long, Tuple3<Double, Double, Integer>> vehiclePositionMap;

	public VehiclePositionControl(String prefix) {
		System.err.println("inizializzato VehiclePositionControl");
		vehiclePositionMap = new HashMap<>();
	}

   
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public boolean execute() {
		
		if(!vehiclePositionMap.isEmpty()) {
			
//			System.out.println("position control "+CommonState.getTime()/1000.0);
			
//			 number of nodes in the network must be equal to the number of positions updated
			if (vehiclePositionMap.size() != Network.size()) {
				
				System.err.println("ERROR: The number of vehicles " + vehiclePositionMap.size() + " and network nodes " + Network.size() + " is different at time "+CommonState.getTime()/1000.0);
				System.exit(0);
			}

			// if there are positions to update
			else {

				Iterator it = vehiclePositionMap.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pair = (Map.Entry) it.next();

					// searches for VanetNode associated with the Vehicle
					VanetNode vanetNode = VanetNode.getVanetNode((long) pair.getKey());

					// update position
					Tuple3<Double, Double, Integer> position = (Tuple3<Double, Double, Integer>) pair.getValue();
					vanetNode.setX(position.getItem1());
					vanetNode.setY(position.getItem2());
					vanetNode.setLane(position.getItem3());

//					System.out.println(vehiclePositionMap.entrySet().size()+" asd");
					it.remove(); // avoids a ConcurrentModificationException and removes entry
				}
			}
		}
		

		return false;
	}

	public static Map<Long, Tuple3<Double, Double, Integer>> getVehiclePositionMap() {
		return vehiclePositionMap;
	}

	public static void setVehiclePositionMap(Map<Long, Tuple3<Double, Double, Integer>> vehiclePositionMap) {
		VehiclePositionControl.vehiclePositionMap = vehiclePositionMap;
	}

}

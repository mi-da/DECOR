package se.mida.entity;

import java.util.UUID;

public class VanetMessage {
	
	private String id;
	private VanetNode originalSender;
	private VanetNode sender;
	private int hop;
	
	// lane change instruction
	private int laneChange;
	private int ttl;
	
	public VanetMessage(VanetNode originalSender,VanetNode sender,int laneChange,int ttl) {
		this.originalSender = originalSender;
		this.sender=sender;
		this.laneChange=laneChange;
		this.ttl=ttl;		
		id = UUID.randomUUID().toString();
		hop = 0;
	}

	
	private VanetMessage(String id, VanetNode originalSender,VanetNode sender,int laneChange,int ttl) {
		this.originalSender = originalSender;
		this.sender=sender;
		this.laneChange=laneChange;
		this.ttl=ttl;	
		this.id = id;
	}

	public VanetNode getSender() {
		return sender;
	}

	public void setSender(VanetNode sender) {
		this.sender = sender;
	}
	
	public VanetNode getOriginalSender() {
		return originalSender;
	}
	
	public String getId() {
		return id;
	}
	
	public int getLaneChange() {
		return laneChange;
	}

	public void setLaneChange(int laneChange) {
		this.laneChange = laneChange;
	}

	public int getTtl() {
		return ttl;
	}

	public void setTtl(int ttl) {
		this.ttl = ttl;
	}
	
	public VanetMessage copyMessage(VanetNode newSender) {
		VanetMessage vm = new VanetMessage(this.id,this.originalSender, newSender,this.laneChange,this.ttl);
		vm.setHop(this.hop+1);	
		return vm;
	}
	
	// two message are equals if they have the same id
	@Override
	public boolean equals(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    final VanetMessage other = (VanetMessage) obj;
	    if (this.id.equals(other.id)) {
	        return true;
	    }
	    return false;
	}

	public int getHop() {
		return hop;
	}

	public void setHop(int hop) {
		this.hop = hop;
	}



}

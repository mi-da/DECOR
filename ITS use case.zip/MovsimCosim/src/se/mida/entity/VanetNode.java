package se.mida.entity;

import peersim.core.CommonState;
import peersim.core.GeneralNode;
import peersim.core.Network;
import se.mida.linkable.VanetNodeLinkable;
import se.mida.protocol.strategy.AControlStrategy;


/**
 * Extends the class GeneralNode of PeerSim to create a prototype of a Vanet's node
 */
public class VanetNode extends GeneralNode {

	private long vehicleID;
	private String label;
	private int lane;

	public static double radius = 200; // 200; // discovery radius (meters)
	public static int max_degree = 10; // 10; // max number of neighbors

	//Local net of a node (the neighbors list)
	public VanetNodeLinkable localNet;
	//Coordinate of the node in the space
	private double x, y;
	//Control strategy to keep the neighbors of the node see {@link cs.project.protocol.strategy.AControlStrategy}
	public AControlStrategy cs;
	///////////////////////////////////////
	
	// lane restriction (should not be here)
	private int laneChange;
	private int ttl;


	/**
	 * The VanetNode will be initialized from the initializers see {@link cs.project.initializer.VanetInitializer}
	 * @param prefix
	 **/
	public VanetNode(String prefix) {
		super(prefix);
		laneChange=0;
		ttl = 0;
	}

	// searches for VanetNode associated with the Vehicle
	public static VanetNode getVanetNode(long vehicleId) {
		for (int i = 0; i < Network.size(); i++) {
			VanetNode vanetNode = (VanetNode) Network.get(i);
			if (vanetNode.getVehicleID() == vehicleId) 
				return vanetNode;
		}
		System.err.println("VanetNode getVanetNode: no node associated with vehicle id "+vehicleId);
		return null;
	}
	
	public static void printNetwork() {
		System.out.println();
		for (int i = 0; i < Network.size(); i++) {
			VanetNode vanetNode = (VanetNode) Network.get(i);
			System.out.println("-- VanetNode: "+vanetNode.getVehicleID());
		}
		System.out.println();
	}
	
	public void printNeighbors() {
		System.out.print("Node:"+this.getVehicleID()+" Neighbours:");
		
		for (int i = 0; i < this.localNet.getNeighbors().size(); i++) {
			VanetNode neighborNode = this.localNet.getNeighbors().get(i);
			System.out.print(neighborNode.getVehicleID());
			if(i!=(this.localNet.getNeighbors().size()-1))
				System.out.print(",");
		}
//		System.out.print(" "+CommonState.getIntTime()/1000.0);
		System.out.println();
	}

	public long getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(long vehicleID) {
		this.vehicleID = vehicleID;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public int getLaneChange() {
		return laneChange;
	}

	public void setLaneChange(int laneChange) {
		this.laneChange = laneChange;
	}
	
	public int getTtl() {
		return ttl;
	}

	public void setTtl(int ttl) {
		this.ttl = ttl;
	}

	public int getLane() {
		return lane;
	}

	public void setLane(int lane) {
		this.lane = lane;
	}

}

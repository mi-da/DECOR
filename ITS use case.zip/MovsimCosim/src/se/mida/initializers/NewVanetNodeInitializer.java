package se.mida.initializers;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Network;
import peersim.core.Node;
import peersim.dynamics.NodeInitializer;
import se.mida.entity.VanetNode;
import se.mida.linkable.VanetNodeLinkable;
import se.mida.protocol.p2p.VanetProtocol;
import se.mida.protocol.strategy.AControlStrategy;

public class NewVanetNodeInitializer implements NodeInitializer {
	
	private static final String PAR_CONTROLSTRATEGY = "controlstrategy";
	private static final String VANET_PROT = "vanet_prot";

	private final String csPrefix;
	private final int vanet_pid;
	
	
    public NewVanetNodeInitializer(String prefix) {
    	csPrefix = Configuration.getString(prefix + "." + PAR_CONTROLSTRATEGY, "RANDOM");
    	vanet_pid = Configuration.getPid(prefix + "." + VANET_PROT);
    }


	@Override
	public void initialize(Node n) {
		
		VanetNode newVanetNode = (VanetNode)n;		
		newVanetNode.localNet = new VanetNodeLinkable();
		newVanetNode.cs = AControlStrategy.getStrategy(newVanetNode, csPrefix);	
		
	}

}

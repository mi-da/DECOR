package se.mida.linkable;

import java.util.ArrayList;
import java.util.List;

import se.mida.entity.VanetNode;

/**
 * General implementation of ILinkable interface with VanetNode
 */
public class VanetNodeLinkable implements ILinkable<VanetNode>{
    
    List<VanetNode> _neighbors = new ArrayList<>();
       
    @Override
    public boolean contain(VanetNode t){
        return _neighbors.contains(t);
    }
    
    @Override
    public boolean addNode(VanetNode t) {
        if(!_neighbors.contains(t))
            return _neighbors.add(t);
        return false;
    }

    @Override
    public boolean removeNode(VanetNode t) {
        return _neighbors.remove(t);
    }
    
    @Override
    public VanetNode removeNode(int i) {
        return _neighbors.remove(i);
    }

    @Override
    public int size() {
        return _neighbors.size();
    }

    @Override
    public List<VanetNode> getNeighbors() {
        return _neighbors;
    }
    
}


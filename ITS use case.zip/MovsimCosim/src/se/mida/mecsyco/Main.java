package se.mida.mecsyco;

import java.util.ArrayList;

import mecsyco.core.agent.EventMAgent;
import mecsyco.core.agent.ObservingMAgent;
import mecsyco.core.coupling.CentralizedEventCouplingArtifact;
import mecsyco.core.exception.CausalityException;

public class Main {

	public final static double maxSimulationTime = 1200*9; // 1200 seconds = 20 minutes ----  1200*9= 3 hours
	public final static double timeStep = 0.02; // 20 ms

	public static String peersimConfigPath1 = "C:/Users/midaab/workspace-its/MovsimCosim/conf/configPeerSim.txt";

	//	public final static String movsimConfigPath = "-fC:/Users/midaab/workspace-its/movsim-develop/mySim/ringRoad/ringroad_2lanes.xprj";
	  public final static String movsimConfigPath = "-fC:/Users/midaab/workspace-its/movsim-develop/mySim/routingStraight/routing.xprj";

	 // public final static String movsimConfigPath = "-fC:/Users/midaab/workspace-its/movsim-develop/sim/games/routing.xprj";

	//	public final static String movsimConfigPath = "-fC:/Users/midaab/workspace-its/movsim-develop/sim/features/output/mirko_city_example.xprj";

	public static ObservingMAgent observingAgent;

	public static ArrayList<EventMAgent> coSimulate() {
		
		ArrayList<EventMAgent> agents = new ArrayList<>();

		String[] argsPeersim = new String[1];
		argsPeersim[0] = peersimConfigPath1;

		// Agent1 - PeerSim Agent
		EventMAgent peersimAgent = new EventMAgent("peersimAgent", maxSimulationTime); // simulation time in milliseconds
		PeersimModelArtifact peersimArtifact = new PeersimModelArtifact(maxSimulationTime);
		peersimArtifact.setInitialParameters(argsPeersim);
		peersimAgent.setModelArtifact(peersimArtifact);
        agents.add(peersimAgent);
		
		// Agent2 - MovSim Agent
		EventMAgent movsimAgent = new EventMAgent("movsimAgent", maxSimulationTime);
		String[] argsMovsim = new String[1];
		argsMovsim[0] = movsimConfigPath;
		MovsimModelArtifact movsimArtifact = new MovsimModelArtifact();
		movsimArtifact.setInitialParameters(argsMovsim);
		movsimAgent.setModelArtifact(movsimArtifact);
		agents.add(movsimAgent);

		// MAIN COUPLING ARTIFACTS

		// Coupling Artifact - Initial (Vehicle) Conditions
		CentralizedEventCouplingArtifact initial_vehicles = new CentralizedEventCouplingArtifact();
		movsimAgent.addOutputCouplingArtifact(initial_vehicles, "initial_vehicles");
		peersimAgent.addInputCouplingArtifact(initial_vehicles, "initial_vehicles");

		// Coupling Artifact - Vehicles Entering
		CentralizedEventCouplingArtifact vehicle_enter = new CentralizedEventCouplingArtifact();
		movsimAgent.addOutputCouplingArtifact(vehicle_enter, "vehicle_enter");
		peersimAgent.addInputCouplingArtifact(vehicle_enter, "vehicle_enter");

		// Coupling Artifact - Vehicles Exiting
		CentralizedEventCouplingArtifact vehicle_exit = new CentralizedEventCouplingArtifact();
		movsimAgent.addOutputCouplingArtifact(vehicle_exit, "vehicle_exit");
		peersimAgent.addInputCouplingArtifact(vehicle_exit, "vehicle_exit");

		// Coupling Artifact - Vehicles Position
		CentralizedEventCouplingArtifact vehicles_position = new CentralizedEventCouplingArtifact();
		movsimAgent.addOutputCouplingArtifact(vehicles_position, "vehicles_position");
		peersimAgent.addInputCouplingArtifact(vehicles_position, "vehicles_position");

		// OPTIONAL COUPLING ARTIFACTS

		// Coupling Artifact - Lane Change Gossip Ambulance
		CentralizedEventCouplingArtifact lane_changes = new CentralizedEventCouplingArtifact();
		peersimAgent.addOutputCouplingArtifact(lane_changes, "lane_changes");
		movsimAgent.addInputCouplingArtifact(lane_changes, "lane_changes");

		// START
		peersimAgent.startModelSoftware();
		movsimAgent.startModelSoftware();

		// Start the co-simulation		
		try {
			// co-initialization allows to set-up new VANET nodes/vehicles from initalial conditions of MovSim
			movsimAgent.coInitialize();
			peersimAgent.coInitialize();

			peersimAgent.start();
			movsimAgent.start();
		} catch (CausalityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return agents;		
	}

}
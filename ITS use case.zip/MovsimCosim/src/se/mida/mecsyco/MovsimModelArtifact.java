package se.mida.mecsyco;

import mecsyco.core.model.ModelArtifact;
import mecsyco.core.type.ArrayedSimulVector;
import mecsyco.core.type.HashedSimulMap;
import mecsyco.core.type.SimulData;
import mecsyco.core.type.SimulEvent;
import mecsyco.core.type.SimulMap;
import mecsyco.core.type.Tuple2;
import mecsyco.core.type.Tuple3;
import se.mida.control.AddRemoveVehicleControl;
import se.mida.viewer.ui.AppFrame;
import se.mida.viewer.ui.ViewProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBException;

import org.movsim.SimulationScan;
import org.movsim.autogen.Movsim;
import org.movsim.input.MovsimCommandLine;
import org.movsim.input.ProjectMetaData;
import org.movsim.logging.Logger;
import org.movsim.roadmappings.PosTheta;
import org.movsim.roadmappings.RoadMapping;
import org.movsim.shutdown.ShutdownHooks;
import org.movsim.simulator.InitialConditions;
import org.movsim.simulator.Simulator;
import org.movsim.simulator.roadnetwork.LaneSegment;
import org.movsim.simulator.roadnetwork.RoadNetwork;
import org.movsim.simulator.roadnetwork.RoadSegment;
import org.movsim.simulator.roadnetwork.boundaries.AbstractTrafficSource;
import org.movsim.simulator.vehicles.Vehicle;
import org.movsim.simulator.vehicles.lanechange.LaneChangeModel;
import org.movsim.viewer.util.LocalizationStrings;
import org.movsim.viewer.util.SwingHelper;
import org.movsim.xml.InputLoader;
import org.xml.sax.SAXException;

public class MovsimModelArtifact extends ModelArtifact {

	private Simulator simulator;
	private RoadNetwork roadNetwork;
	private AppFrame appFrame;
	String[] args;

	public MovsimModelArtifact() {
		super("movSim");
	}

	@Override
	public void processInternalEvent(double time) {
		//		System.out.println("Mecsyco process event for MovSim at time: " + Math.round(time*1000.0)/1000.0);;
		simulator.getSimulationRunnable().processNextInternalEventRunnable();
	}

	@Override
	public double getNextInternalEventTime() {
		//		System.out.println("Mecsyco get next internal event time for MovSim "+Math.round(simulator.getSimulationRunnable().simulationTime*100.0)/100.0);
		return Math.round(simulator.getSimulationRunnable().simulationTime * 1000.0) / 1000.0;
	}

	@Override
	public double getLastEventTime() {
		//		System.out.println("Mecsyco get last MovSim event time "+Math.round((simulator.getSimulationRunnable().simulationTime - simulator.getSimulationRunnable().dt)*100.0)/100.0);
		return (Math.round((simulator.getSimulationRunnable().simulationTime - simulator.getSimulationRunnable().dt) * 1000.0) / 1000.0);
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void processExternalInputEvent(SimulEvent event, String port) {
		//		System.out.println("Mecsyco process external input for MovSim");

		SimulData data = event.getData();

		// Initialization of data coming from Modelica
		if (event.getTime() == -1) {
			// nothing now
		}

		// Vehicle enter
		else if (port == "lane_changes") {

			SimulMap<Long, Integer> sm = (SimulMap<Long, Integer>) data;
			Map map = sm.asMap();

			Iterator it = map.entrySet().iterator();
			while (it.hasNext()) {

				Map.Entry pair = (Map.Entry) it.next();

				long vehicleId = (long) pair.getKey();
				int laneChange = (int) pair.getValue();

				// look for vehicle with vehicleID
				outerloop: for (final RoadSegment roadSegment : roadNetwork.getRoadSegments()) {

					for (Vehicle vehicle : roadSegment) {

						if (vehicle.getId() == vehicleId) {
							LaneChangeModel lcm = vehicle.getLaneChangeModel();

							if (laneChange != 0) {
								lcm.setMandatoryChangeToLane(laneChange);
								//								System.out.println("Veicolo "+vehicle.getId()+" forced to lane "+laneChange);
							} else {
								lcm.unsetMandatoryChangeToLane();
								//								System.out.println("Veicolo "+vehicle.getId()+" � libero");
							}
							// stop looking for the vehicle
							break outerloop;
						}
					}
				}
			}

		}

	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public SimulEvent getExternalOutputEvent(String port) {
		System.out.println("Mecsyco get external output from MovSim "+port+" time: "+getLastEventTime());

		// Propagate initial conditions (vehicles already in the network)
		if (port == "initial_vehicles") {

			ArrayList<Vehicle> newVehicles = InitialConditions.getInitialVehicles();

			if (newVehicles != null && !newVehicles.isEmpty()) {
				// id and label of vehicles
				Map<Long, String> newVehiclesMap = new HashMap();

				for (Vehicle vehicle : newVehicles) {
					if (vehicle.type() == Vehicle.Type.VEHICLE)
						newVehiclesMap.put(vehicle.getId(), vehicle.getLabel());
				}
				// remove added vehicles to avoid multiple insertions
				InitialConditions.setInitialVehicles(new ArrayList<Vehicle>());

				SimulMap<Long, String> sm = new HashedSimulMap<>(newVehiclesMap);
				return new SimulEvent(sm, this.getLastEventTime());
			}
		}

		if (port == "vehicle_enter") {

			ArrayList<Vehicle> newVehicles = AbstractTrafficSource.getEnteredVehicles();

			if (!newVehicles.isEmpty()) {

				// id and label of vehicles
				Map<Long, String> newVehiclesMap = new HashMap();

				for (Vehicle vehicle : newVehicles) {
					if (vehicle.type() == Vehicle.Type.VEHICLE)
						newVehiclesMap.put(vehicle.getId(), vehicle.getLabel());
				}
				// remove added vehicles to avoid multiple insertions
				AbstractTrafficSource.setEnteredVehicles((new ArrayList<Vehicle>()));

				SimulMap<Long, String> sm = new HashedSimulMap<>(newVehiclesMap);
				return new SimulEvent(sm, this.getLastEventTime());

			}

		} else if (port == "vehicle_exit") {

			ArrayList<Long> vehiclesIdsToRemove = new ArrayList<>();

			// list of vehicles removed from movSim
			ArrayList<Vehicle> removedVehicles = LaneSegment.getRemovedVehicles();

			for (Vehicle vehicle : removedVehicles) {
				vehiclesIdsToRemove.add(vehicle.getId());
			}
			// remove outgoing vehicle to avoid multiple deletions
			LaneSegment.setRemovedVehicles(new ArrayList<Vehicle>());

			Long[] a = vehiclesIdsToRemove.toArray(new Long[vehiclesIdsToRemove.size()]);

			ArrayedSimulVector<Long> sv = new ArrayedSimulVector<>(a);
			return new SimulEvent(sv, this.getLastEventTime());

		}

		else if (port == "vehicles_position") {

			// store position of vehicles id=key value=position			
			Map<Long, Tuple3<Double, Double, Integer>> vehiclePositionsMap = new HashMap();

			// custom - prendo i veicoli       
			for (final RoadSegment roadSegment : roadNetwork.getRoadSegments()) {
				RoadMapping rm = roadSegment.roadMapping();

				for (Vehicle vehicle : roadSegment) {
					if (vehicle.type() != Vehicle.Type.OBSTACLE) {

						// posizione assoluta nello spazio del veicolo
						PosTheta posTheta = rm.map(vehicle.physicalQuantities().getMidPosition(), -rm.laneCenterOffset(vehicle.getContinousLane()));
						double xPos = posTheta.getScreenX();
						double yPos = posTheta.getScreenY();
						int lane = vehicle.lane();
						vehiclePositionsMap.put(vehicle.getId(), new Tuple3<Double, Double, Integer>(xPos, yPos, lane));
					}
				}
			}

			//			System.out.println("MovSim invia position map at "+this.getLastEventTime());
			SimulMap<Long, Tuple3<Double, Double, Integer>> sm = new HashedSimulMap<>(vehiclePositionsMap);
			return new SimulEvent(sm, this.getLastEventTime());
		}

		return null;
	}

	@Override
	public void initialize() {
		//		System.out.println("Mecsyco requests MovSim initialization");

		ProjectMetaData projectMetaData = ProjectMetaData.getInstance();
		if (!projectMetaData.hasProjectName()) {
			throw new IllegalArgumentException("no xml simulation configuration file provided.");
		}
		Movsim movsimInput = InputLoader.unmarshallMovsim(projectMetaData.getInputFile());
		Simulator simulator = new Simulator(movsimInput);
		simulator.setMaxSimulationTime(Main.maxSimulationTime);

		this.simulator = simulator;
		this.roadNetwork = simulator.getRoadNetwork();
		
		
        // With GUI
		final ResourceBundle resourceBundle = ResourceBundle.getBundle(LocalizationStrings.class.getName(), Locale.getDefault());
		Properties properties = ViewProperties.loadProperties(projectMetaData);
		appFrame = new AppFrame(resourceBundle, projectMetaData, properties, simulator);
		
	}

	@Override
	public void finishSimulation() {
		SwingHelper.closeWindow(appFrame);
		ShutdownHooks.INSTANCE.onShutDown();
		System.out.println("Mecsyco finish MovSim simulation");
	}

	@Override
	public void setInitialParameters(String[] args) {

		System.out.println("Mecsyco set initialial parameters for MovSim");
		Locale.setDefault(Locale.US);
		Logger.initializeLogger();
		MovsimCommandLine.parse(args);
		this.args = args;

	}

}
package se.mida.mecsyco;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.movsim.simulator.roadnetwork.boundaries.AbstractTrafficSource;
import org.movsim.simulator.vehicles.Vehicle;

import mecsyco.core.model.ModelArtifact;
import mecsyco.core.type.ArrayedSimulVector;
import mecsyco.core.type.HashedSimulMap;
import mecsyco.core.type.SimulData;
import mecsyco.core.type.SimulEvent;
import mecsyco.core.type.SimulMap;
import mecsyco.core.type.Tuple1;
import mecsyco.core.type.Tuple2;
import mecsyco.core.type.Tuple3;
import peersim.Simulator;
import peersim.core.CommonState;
import peersim.core.Network;
import peersim.core.Node;
import peersim.edsim.EDSimulator;
import se.mida.control.AddRemoveVehicleControl;
import se.mida.control.VehiclePositionControl;
import se.mida.entity.VanetNode;

public class PeersimModelArtifact extends ModelArtifact {

	private String[] args;
	private double maxSimulationTime;
	public static Node monitoringNode;
	


	public PeersimModelArtifact(double maxSimulationTime) {
		super("peerSim");
		this.maxSimulationTime = maxSimulationTime;
	}

	@Override
	public void processInternalEvent(double time) {
		//		System.out.println("Mecsyco process event for PeerSim at time: " + Math.round(EDSimulator.getNextEventTime()*1000.0)/1000.0);
		while (time == EDSimulator.getNextEventTime())
			EDSimulator.executeNext();
	}

	@Override
	public double getNextInternalEventTime() {

		double nextEventTime = EDSimulator.getNextEventTime();

		//		System.out.println("Mecsyco get next internal event time for PeerSim "+Math.round(nextEventTime*100.0)/100.0);
		return Math.round(nextEventTime * 1000.0) / 1000.0;

	}

	@Override
	public double getLastEventTime() {
		//		System.out.println("Mecsyco get last PeerSim event time "+Math.round(EDSimulator.getLastEventTime()*100.0)/100.0);	
		return Math.round(EDSimulator.getLastEventTime() * 1000.0) / 1000.0;
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void processExternalInputEvent(SimulEvent event, String port) {
		System.out.println("Mecsyco process input from PeerSim "+port+" "+event.getTime());

		SimulData data = event.getData();

		// Initialization of data coming from MovSim
		if (event.getTime() == -1) {

			if (port == "initial_vehicles") {
				SimulMap<Long, String> sm = (SimulMap<Long, String>) data;
				Map map = sm.asMap();
				//				System.out.println("New vehicles from initial conditions "+map.toString());
				AddRemoveVehicleControl.setAddVehicles(map);

			}
		}

		// Vehicle enter
		else if (port == "vehicle_enter") {
			SimulMap<Long, String> sm = (SimulMap<Long, String>) data;
			Map map = sm.asMap();
			AddRemoveVehicleControl.setAddVehicles(map);
			//			if(!sv.aslist().isEmpty())
			//				System.out.println("PeerSim riceve richiesta entrata veicolo al tempo "+event.getTime());	

		}

		// Vehicle exit
		else if (port == "vehicle_exit") {
			ArrayedSimulVector<Long> sv = (ArrayedSimulVector<Long>) data;
			AddRemoveVehicleControl.setRemoveVehicles(sv.aslist());
		}

		// Vehicles position update
		else if (port == "vehicles_position") {
			SimulMap<Tuple1<Long>, Tuple3<Double, Double, Integer>> sm = (SimulMap<Tuple1<Long>, Tuple3<Double, Double, Integer>>) data;
			Map map = sm.asMap();
			VehiclePositionControl.setVehiclePositionMap(map);
			//		    System.out.println("PeerSim riceve mappa "+map.size()+" con tempo "+event.getTime());		    

		}

	}

	@Override
	public SimulEvent getExternalOutputEvent(String port) {

		// Lane Changes
		if (port == "lane_changes") {

			// id and lane change of vehicles (0 if no-lane was requested)
			Map<Long, Integer> laneChangesMap = new HashMap();

			for (int i = 0; i < Network.size(); i++) {
				VanetNode currentNode = (VanetNode) Network.get(i);
				laneChangesMap.put(currentNode.getVehicleID(), currentNode.getLaneChange());
			}

			SimulMap<Long, Integer> sm = new HashedSimulMap<>(laneChangesMap);
			return new SimulEvent(sm, EDSimulator.getCurrentSimulationTime());

		}

		return null;
	}

	@Override
	public void initialize() {

		//		System.out.println("MECSYCO requests PeerSim initialization \n");
		Simulator.start(args, maxSimulationTime);
		//		Util.initializeComponentsToNetworkNodes();
	}

	@Override
	public void finishSimulation() {
		System.out.println("MECSYCO requests to stop PeerSim \n");

		EDSimulator.analysisAfterSimulation();
		//		System.out.println("Simulazione finita in PeerSim "+Main.observingAgent.isSimulationEnd());
		modelLogger.info("ends simulation at time {}", EDSimulator.getCurrentSimulationTime());

	}

	@Override
	public void setInitialParameters(String[] args) {
		this.args = args;
	}

}
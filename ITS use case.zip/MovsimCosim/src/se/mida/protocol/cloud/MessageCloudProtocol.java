package se.mida.protocol.cloud;

import java.util.ArrayList;
import peersim.cdsim.CDProtocol;
import peersim.config.FastConfig;
import peersim.core.CommonState;
import peersim.core.Network;
import peersim.core.Node;
import peersim.edsim.EDProtocol;
import peersim.edsim.EDSimulator;
import peersim.transport.Transport;
import se.mida.control.SimulationObserver;
import se.mida.entity.VanetMessage;
import se.mida.entity.VanetNode;
import se.mida.initializers.CloudNodeInitializer;
import se.mida.mecsyco.PeersimModelArtifact;

public class MessageCloudProtocol implements CDProtocol, EDProtocol {

	private ArrayList<VanetMessage> processedMessages;
	private int generatedStep;
	
	// message related attributes
	private boolean generate;

	public MessageCloudProtocol(String prefix) {
		processedMessages = new ArrayList<>();
		generatedStep = 1;
		generate=true; 
	}

	/**
	 * @param node
	 * @param protocolID 
	 */
	@Override
	public void nextCycle(Node node, int protocolID) {

		VanetNode thisNode = (VanetNode) node;
		
//		System.out.println(thisNode.getVehicleID()+" lane:"+thisNode.getLane());

		// AMBULANCE starts gossip message
		if (thisNode.getLabel().equals("AMBULANCE")) {		
			
			if(generate) {
				
				// put Ambulance on lane 2
				thisNode.setLaneChange(2);

				VanetNode receiverNode;

//				System.out.println("Nodo:" + thisNode.getVehicleID() + " " + thisNode.getLabel() + " crea messaggio di allerta verso il Cloud! at time "+CommonState.getTime());
				
                // send message to Cloud
				receiverNode = CloudNodeInitializer.cloudNode;
//				System.out.println("Ambulance invia messaggio a nodo: id="+receiverNode.getID()+" label="+receiverNode.getLabel());

				// change to lane 1 for 4secs (i.e., 0.2*TTL=x seconds)
				VanetMessage vm = new VanetMessage(thisNode, thisNode, 1, 400000);
				((Transport) receiverNode.getProtocol(FastConfig.getTransport(protocolID))).send(thisNode, receiverNode, vm, protocolID);
				
				SimulationObserver.incrementNumberOfSentMess();

				generate=false;
			}
			else {
				generatedStep++;
				if(generatedStep==50000) {
//					generate=true;
					generatedStep=0;
				}
			}
			

		}
		// CARS decrement TTL of received alert messages (allows remove imposed restrictions e.g., lane changes)
		else {
			int currentTTL = thisNode.getTtl();

			if (currentTTL == 0) {
				thisNode.setLaneChange(0);
			}
			else 
				thisNode.setTtl(currentTTL - 1);
		}
	}

	@Override
	public void processEvent(Node node, int pid, Object event) {
		VanetMessage vm = (VanetMessage) event;
		VanetNode thisNode = (VanetNode) node;

		// System.out.println("Nodo:"+((VanetNode)node).getVehicleID()+" ho ricevuto da Nodo:"+vm.getSender().getVehicleID()+" originalSender:"+vm.getOriginalSender().getVehicleID()+" at time:"+CommonState.getTime()/1000.0);

		// Cloud sends message to cars
		if (thisNode.getLabel().equals("CLOUD")) {
//			System.out.println("Cloud node "+node.getID()+" receives message from "+vm.getSender().getLabel());
			
			for (int i = 0; i < Network.size(); i++) {
				VanetNode receiverNode = (VanetNode) Network.get(i);
				
				// new messages avoid concurrent modifications in java (commented speed up simulation concurrent modifications do not occur)
				VanetMessage nvm = vm.copyMessage(thisNode);

				// do not send the message to the original sender and the previous sender
				if (receiverNode.getLabel().equals("CAR")) {
					((Transport) receiverNode.getProtocol(FastConfig.getTransport(pid))).send(thisNode, receiverNode, nvm, pid);
					SimulationObserver.incrementNumberOfSentMess();
				}
			}
		}
		
		
		
		// Cars receives messages from cloud
		if (thisNode.getLabel().equals("CAR")) {
//			System.out.println("CAR node "+node.getID()+" receives message from "+vm.getSender().getLabel());
			thisNode.setLaneChange(vm.getLaneChange());
			thisNode.setTtl(vm.getTtl());
		}

	}

	@Override
	public MessageCloudProtocol clone() {
		MessageCloudProtocol gp = null;
		try {
			gp = (MessageCloudProtocol) super.clone();
			gp.processedMessages = new ArrayList<VanetMessage>();
		} catch (CloneNotSupportedException e) {
		}
		return gp;
	}

}

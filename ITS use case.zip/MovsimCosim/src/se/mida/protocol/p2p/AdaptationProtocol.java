package se.mida.protocol.p2p;

import java.util.ArrayList;

import peersim.cdsim.CDProtocol;
import peersim.core.Network;
import peersim.core.Node;
import peersim.edsim.EDProtocol;
import peersim.edsim.EDSimulator;
import se.mida.control.SimulationObserver;
import se.mida.entity.VanetNode;

public class AdaptationProtocol implements CDProtocol, EDProtocol {

	// array of vehicles in front
	private ArrayList<VanetNode> nodeVehiclesInFront;

	// message related attributes
	private boolean requestGenerated;
	private boolean adaptationDone;
	private double adaptationRequestTime;
	private double adaptationEndTime;

	public AdaptationProtocol(String prefix) {
		requestGenerated = false;
		adaptationDone = false;
		setAdaptationRequestTime(-1);
		setAdaptationEndTime(-1);
		nodeVehiclesInFront = new ArrayList<>();
	}

	/**
	 * @param node
	 * @param protocolID 
	 */
	@Override
	public void nextCycle(Node node, int protocolID) {

		VanetNode thisNode = (VanetNode) node;

		// AMBULANCE register adaptation time (i.e., adaptationRequestTime and adaptationEndTime)
		if (thisNode.getLabel().equals("AMBULANCE") && !adaptationDone) {

			if (!requestGenerated) {

//				System.out.println("Ambulance Adaptation Protocol Generate at time: " + EDSimulator.getCurrentSimulationTime() + " milliseconds");
				setAdaptationRequestTime(EDSimulator.getCurrentSimulationTime());

				requestGenerated = true;

				for (int i = 0; i < Network.size(); i++) {
					VanetNode nodeVehicle = (VanetNode) Network.get(i);
					// if the nodes is on the reserved lane must be added to array
					if (nodeVehicle.getLabel().equals("CAR") && nodeVehicle.getLane() == 2) {
						nodeVehiclesInFront.add(nodeVehicle);
					}
				}

				//				for (VanetNode vanetNode : nodeVehiclesInFront) {
				//					System.out.print(vanetNode.getVehicleID()+" ");
				//				}
				//				System.out.println();

			}
			
			// controls node that adapted or went out of the road
			ArrayList<VanetNode> nodesToRemove = new ArrayList<VanetNode>();
			for (VanetNode vanetNodeInFront : nodeVehiclesInFront) {

				if (!vanetNodeInFront.isUp()) {
					nodesToRemove.add(vanetNodeInFront);
//					System.out.println("nodo " + vanetNodeInFront.getVehicleID() + " uscito dalla simulazione");
				}
				if (vanetNodeInFront.getLane() == 1) {
					nodesToRemove.add(vanetNodeInFront);
//					System.out.println("nodo " + vanetNodeInFront.getVehicleID() + " si � adattato a " + EDSimulator.getCurrentSimulationTime());
				}
			}
			nodeVehiclesInFront.removeAll(nodesToRemove);

			if (nodeVehiclesInFront.isEmpty()) {
				setAdaptationEndTime(EDSimulator.getCurrentSimulationTime());
//				System.out.println("Adaptation end time is " + EDSimulator.getCurrentSimulationTime());

//				System.out.println("Finale Adaptation time is " + (adaptationEndTime - adaptationRequestTime) + " seconds");
				double adaptationTime = adaptationEndTime - adaptationRequestTime;
				SimulationObserver.addAdaptationTime(adaptationTime);
				
				adaptationDone = true;
			}

		}

	}

	@Override
	public void processEvent(Node node, int pid, Object event) {

	}

	@Override
	public AdaptationProtocol clone() {
		AdaptationProtocol ap = null;
		try {
			ap = (AdaptationProtocol) super.clone();
			ap.nodeVehiclesInFront = new ArrayList<VanetNode>();
		} catch (CloneNotSupportedException e) {
		}
		return ap;
	}

	public double getAdaptationRequestTime() {
		return adaptationRequestTime;
	}

	public void setAdaptationRequestTime(double adaptationRequestTime) {
		this.adaptationRequestTime = adaptationRequestTime;
	}

	public double getAdaptationEndTime() {
		return adaptationEndTime;
	}

	public void setAdaptationEndTime(double adaptationEndTime) {
		this.adaptationEndTime = adaptationEndTime;
	}

}

package se.mida.protocol.p2p;

import java.util.ArrayList;
import peersim.cdsim.CDProtocol;
import peersim.config.FastConfig;
import peersim.core.CommonState;
import peersim.core.Node;
import peersim.edsim.EDProtocol;
import peersim.edsim.EDSimulator;
import peersim.transport.Transport;
import se.mida.control.SimulationObserver;
import se.mida.entity.VanetMessage;
import se.mida.entity.VanetNode;
import se.mida.mecsyco.PeersimModelArtifact;

public class GossipProtocolOriginal implements CDProtocol, EDProtocol {

	private ArrayList<VanetMessage> processedMessages;
	private int generatedStep;
	
	// message related attributes
	private boolean generate;

	public GossipProtocolOriginal(String prefix) {
		processedMessages = new ArrayList<>();
		generatedStep = 1;
		generate=true; 
	}

	/**
	 * @param node
	 * @param protocolID 
	 */
	@Override
	public void nextCycle(Node node, int protocolID) {

		VanetNode thisNode = (VanetNode) node;
		
//		System.out.println(thisNode.getVehicleID()+" lane:"+thisNode.getLane());

		// AMBULANCE starts gossip message
		if (thisNode.getLabel().equals("AMBULANCE")) {		
			
			if(generate) {
				
				// put Ambulance on lane 2 if able to reach neighbors
				if(thisNode.localNet.getNeighbors().size()!=0)
					thisNode.setLaneChange(2);

				VanetNode receiverNode;

//				System.out.println("Nodo:" + thisNode.getVehicleID() + " " + thisNode.getLabel() + " crea messaggio di allerta! at time "+CommonState.getTime());

				// for each neighbor node send a message
				for (int i = 0; i < thisNode.localNet.getNeighbors().size(); i++) {
					receiverNode = thisNode.localNet.getNeighbors().get(i);

					// change to lane 1 for 4secs (i.e., 0.2*TTL=x seconds)
					VanetMessage vm = new VanetMessage(thisNode, thisNode, 1, 400000);
					((Transport) receiverNode.getProtocol(FastConfig.getTransport(protocolID))).send(thisNode, receiverNode, vm, protocolID);
					
					SimulationObserver.incrementNumberOfSentMess();

				}
				
				if(thisNode.localNet.getNeighbors().size()!=0)
					generate=false;
			}
			else {
				generatedStep++;
				if(generatedStep==50000) {
					generate=true;
					generatedStep=0;
				}
			}
			

		}
		// CARS decrement TTL of received alert messages (allows remove imposed restrictions e.g., lane changes)
		else {
			int currentTTL = thisNode.getTtl();

			if (currentTTL == 0) {
				thisNode.setLaneChange(0);
			}
			else 
				thisNode.setTtl(currentTTL - 1);
		}
	}

	@Override
	public void processEvent(Node node, int pid, Object event) {
		VanetMessage vm = (VanetMessage) event;
		VanetNode thisNode = (VanetNode) node;

		// System.out.println("Nodo:"+((VanetNode)node).getVehicleID()+" ho ricevuto da Nodo:"+vm.getSender().getVehicleID()+" originalSender:"+vm.getOriginalSender().getVehicleID()+" at time:"+CommonState.getTime()/1000.0);

		// Sets lane change and ttl if not AMBULANCE
		if (!thisNode.getLabel().equals("AMBULANCE")) {
			thisNode.setLaneChange(vm.getLaneChange());
			thisNode.setTtl(vm.getTtl());
		}

		// Re-inoltra il messaggio ai vicini se non l'ha gi� fatto	
		if (!processedMessages.contains(vm)) {

			VanetNode receiverNode;

			// new messages avoid concurrent modifications in java (commented speed up simulation concurrent modifications do not occur)
			VanetMessage nvm = vm.copyMessage(thisNode);

			for (int i = 0; i < thisNode.localNet.getNeighbors().size(); i++) {
				receiverNode = thisNode.localNet.getNeighbors().get(i);

				// do not send the message to the original sender and the previous sender
				if (receiverNode.getID() != vm.getSender().getID() && receiverNode.getID() != vm.getOriginalSender().getID()) {
					((Transport) receiverNode.getProtocol(FastConfig.getTransport(pid))).send(thisNode, receiverNode, nvm, pid);
					SimulationObserver.incrementNumberOfSentMess();
				}

			}

			processedMessages.add(vm);
		} else {
//			System.out.println("Messaggio gi� processato da nodo "+node.getID()+" size lista "+processedMessages.size());
		}

	}

	@Override
	public GossipProtocolOriginal clone() {
		GossipProtocolOriginal gp = null;
		try {
			gp = (GossipProtocolOriginal) super.clone();
			gp.processedMessages = new ArrayList<VanetMessage>();
		} catch (CloneNotSupportedException e) {
		}
		return gp;
	}

}

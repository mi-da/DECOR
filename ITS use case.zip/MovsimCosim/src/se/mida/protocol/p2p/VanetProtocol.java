package se.mida.protocol.p2p;

import java.util.ArrayList;
import java.util.List;
import peersim.cdsim.CDProtocol;
import peersim.core.CommonState;
import peersim.core.Node;
import peersim.edsim.EDProtocol;
import se.mida.entity.VanetMessage;
import se.mida.entity.VanetNode;
import se.mida.util.Geometry;

public class VanetProtocol implements CDProtocol, EDProtocol {


	public VanetProtocol(String prefix) {
	}

	/**
	 * Check the neighbors to find if someone has going out of trasmission area
	 * and invoke the control strategy to find new connections
	 * 
	 * @param node
	 * @param protocolID 
	 */
	@Override
	public void nextCycle(Node node, int protocolID) {	

		
//		System.out.println("node: "+((VanetNode)node).getVehicleID()+" at time:"+CommonState.getTime()/1000.0);

		VanetNode thisNode = (VanetNode) node;
		VanetNode tmpNode;
		List<VanetNode> nodeToRemove = new ArrayList<>();
		
		// remove unreachable nodes
		for (int i = 0; i < thisNode.localNet.getNeighbors().size(); i++) {
			tmpNode = thisNode.localNet.getNeighbors().get(i);
			if (Geometry.distance(thisNode.getX(), thisNode.getY(), tmpNode.getX(), tmpNode.getY()) >= VanetNode.radius) {
				tmpNode.localNet.removeNode(thisNode);
				nodeToRemove.add(tmpNode);			
			}
		}
		for (VanetNode cNode : nodeToRemove) {
			thisNode.localNet.removeNode(cNode);
		}
		// add nodes according to the control strategy
		thisNode.cs.cycleCheck();
		// print neighbors
//	    thisNode.printNeighbors();
	}
	
	@Override
	public void processEvent(Node node, int pid, Object event) {
	}
	
	@Override
	public VanetProtocol clone() {
		VanetProtocol dolly = null;
		try {
			dolly = (VanetProtocol) super.clone();
		} catch (CloneNotSupportedException e) {
		}
		return dolly;
	}

}

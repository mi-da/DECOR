package se.mida.protocol.strategy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import peersim.core.Network;
import se.mida.entity.VanetNode;
import se.mida.util.Geometry;

/**
 * Control strategy that incorporates two different strategy:
 *  - MAX_DISTANCE, prefer to add nearest nodes and to remove the farther ones
 *  - MIN_DISTANCE, prefer to add farther nodes and to remove the nearest ones
 */
public class DistanceControlStrategy extends AControlStrategy{
    
    private VanetNode _node;

    private Comparator<VanetNode> comp;
    
    protected DistanceControlStrategy(VanetNode node, final int minmax){
        _node = node;
        
        comp = new Comparator<VanetNode>(){
            @Override
            public int compare(VanetNode nod1, VanetNode nod2){
                return minmax * Double.compare( Geometry.distance(_node.getX(), _node.getY(), nod1.getX(), nod1.getY()),
                                                Geometry.distance(_node.getX(), _node.getY(), nod2.getX(), nod2.getY()));
            }
        };
    }
    
    @Override
    public void cycleCheck() {
    	VanetNode n;
        List<VanetNode> possibleAdd = new ArrayList<>();
        for(int i = 0; i<Network.size(); i++){
            n = (VanetNode)Network.get(i);
            if(n == _node || _node.localNet.contain(n)) continue;
            if(Geometry.distance(_node.getX(), _node.getY(), n.getX(), n.getY()) < VanetNode.radius){
                possibleAdd.add(n);
            }
        }
        
        Collections.sort(possibleAdd, comp);
        
        for(int i=0; i<possibleAdd.size(); i++){
            if(_node.localNet.size() < VanetNode.max_degree){
                if(possibleAdd.get(i).cs.tryToAdd(_node)){
                    _node.localNet.addNode(possibleAdd.get(i));
                }
            }else{
                List<VanetNode> neighbors = _node.localNet.getNeighbors();
                Collections.sort(neighbors, comp);
                if(comp.compare(neighbors.get(neighbors.size()-1), possibleAdd.get(i)) > 0){
                    if(possibleAdd.get(i).cs.tryToAdd(_node)){
                        _node.localNet.removeNode(_node.localNet.size()-1).localNet.removeNode(_node);
                        _node.localNet.addNode(possibleAdd.get(i));
                    }
                }else
                    break;
            }
        }
    }

    @Override
    public boolean tryToAdd(VanetNode nodeToAdd) {
        if(_node.localNet.size() >= VanetNode.max_degree){
            Collections.sort(_node.localNet.getNeighbors(), comp);
            if(comp.compare(_node.localNet.getNeighbors().get(_node.localNet.size()-1), nodeToAdd) > 0){
                _node.localNet.removeNode(_node.localNet.size()-1).localNet.removeNode(_node);
            }else
                return false;
        }
        _node.localNet.addNode(nodeToAdd);
        return true;
    }
    
}


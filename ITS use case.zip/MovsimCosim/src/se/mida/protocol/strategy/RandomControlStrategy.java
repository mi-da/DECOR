package se.mida.protocol.strategy;

import peersim.core.CommonState;
import peersim.core.Network;
import se.mida.entity.VanetNode;
import se.mida.util.Geometry;

/**
 * Control strategy that remove and add nodes in a random manner
 */
public class RandomControlStrategy extends AControlStrategy {

	private VanetNode _node;

	protected RandomControlStrategy(VanetNode node) {
		_node = node;
	}

	@Override
	public void cycleCheck() {
		VanetNode n;
		for (int i = 0; i < Network.size(); i++) {
			n = (VanetNode) Network.get(i);
			if (n == _node || _node.localNet.contain(n))
				continue;

			if (Geometry.distance(_node.getX(), _node.getY(), n.getX(), n.getY()) < VanetNode.radius) {
				if (n.cs.tryToAdd(_node)) {
					if (_node.localNet.size() >= VanetNode.max_degree) {
						_node.localNet.removeNode(i % _node.localNet.size()).localNet.removeNode(_node);
					}
					_node.localNet.addNode(n);
				}
			}
		}
	}

	@Override
	public boolean tryToAdd(VanetNode nodeToAdd) {
		if (_node.localNet.size() >= VanetNode.max_degree) {
			_node.localNet.removeNode(CommonState.r.nextInt(VanetNode.max_degree)).localNet.removeNode(_node);
		}
		_node.localNet.addNode(nodeToAdd);
		return true;
	}

}

package se.mida.main;

import java.util.ArrayList;
import java.util.Random;
import org.movsim.output.route.FileIndividualTravelTimesOnRoute;
import mecsyco.core.agent.EventMAgent;
import se.mida.util.FileManager;

public class Main {

	public static void main(String[] args) {

				int currentQ=Integer.valueOf(args[0]);
		
				String configPathMovsim = "C:\\users\\midaab\\workspace-its\\movsim-develop\\mySim\\routingStraight\\routing.xprj";
				String path = "C:\\Users\\midaab\\workspace-its\\MovsimYCalc\\";
				String defaultNameRouting = "routing.tt_individual.route_main_"+currentQ+".csv";
				String qPerHourRegex = "q_per_hour=.*";
				String seedRegex = "seed=.*";
				
				// type of experiment (no adaptation - p2p - fog - cloud)
				
				se.mida.mecsyco.Main.peersimConfigPath1 = "C:/Users/midaab/workspace-its/MovsimCosim/conf/configPeerSim_P2P.txt"; // P2P
//				se.mida.mecsyco.Main.peersimConfigPath1 = "C:/Users/midaab/workspace-its/MovsimCosim/conf/configPeerSim_Cloud.txt"; // Cloud
//				se.mida.mecsyco.Main.peersimConfigPath1 = "C:/Users/midaab/workspace-its/MovsimCosim/conf/configPeerSim_NoAdaptation.txt"; // No Adaptation

				
				// to create unique files
				FileIndividualTravelTimesOnRoute.setQfile(currentQ);
		
				// modify config file Q
				FileManager.modifyFile(configPathMovsim,qPerHourRegex,"q_per_hour=\"" + currentQ + "\" v=\"20\" />");
				
				// modify config file seed
				Random r = new Random();		
				FileManager.modifyFile(configPathMovsim,seedRegex,"seed=\"" + r.nextInt() + "\" crash_exit=\"false\">");
				
				ArrayList<EventMAgent> agents = se.mida.mecsyco.Main.coSimulate();		
				
				// wait threads to finish before modifying files
				for (EventMAgent eventMAgent : agents) {		
					synchronized(eventMAgent) {
						try {
							eventMAgent.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}			
				}		
				FileManager.renameFile(path + defaultNameRouting, path + "adapt q=" + currentQ +" "+System.currentTimeMillis()+".csv");
				FileManager.renameFile(path + "Observer.txt", path + "Observer adapt q=" + currentQ +" "+System.currentTimeMillis()+".csv");

		//
//		calc();
				
	}

}

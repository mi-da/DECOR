package se.mida.main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import se.mida.util.FileManager;

public class MainCalc {

	public static void main(String[] args) {
		
		// new output file
		FileOutputStream fos;	
	    try {
			fos = new FileOutputStream("output.txt");
			PrintStream ps = new PrintStream(fos);
			// column names
			ps.println("q averageTravelTimeAMB averageTravelTimeCAR numberOfSentMessages averageNumberOfMessages averageAdaptationTime stddevAdaptationTime");
			
			for (int q = 0; q < 10000; q += 50)
				FileManager.calculateStatistics("adapt q=" + q + " ", q, 2, ps);
			
			ps.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

}

package se.mida.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

public class FileManager {

	public static void modifyFile(String filePath, String oldString, String newString) {
		File fileToBeModified = new File(filePath);

		String oldContent = "";

		BufferedReader reader = null;

		FileWriter writer = null;

		try {
			reader = new BufferedReader(new FileReader(fileToBeModified));

			//Reading all the lines of input text file into oldContent

			String line = reader.readLine();

			while (line != null) {
				oldContent = oldContent + line + System.lineSeparator();

				line = reader.readLine();
			}

			//Replacing oldString with newString in the oldContent

			String newContent = oldContent.replaceAll(oldString, newString);

			//Rewriting the input text file with newContent

			writer = new FileWriter(fileToBeModified);

			writer.write(newContent);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				//Closing the resources

				reader.close();

				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	* Rename File or Move File in Java example
	*/
	public static void renameFile(String filePath, String newFilePath) {

		//absolute path rename file
		File file = new File(filePath);
		File newFile = new File(newFilePath);
		if (file.renameTo(newFile)) {
			System.out.println("File rename success");
			;
		} else {
			System.out.println("File rename failed");
		}

	}

//	public static void calculateAvgTravelTimeALL(String files_start_with, int q, PrintStream ps) {
//
//		// project directory
//		File dir = new File("C:\\Users\\midaab\\workspace-its\\MovsimYCalc");
//
//		File[] foundFiles = dir.listFiles(new FilenameFilter() {
//			public boolean accept(File dir, String name) {
//				return name.startsWith(files_start_with);
//			}
//		});
//
//		// results
//		ArrayList<Double> travelTimes = new ArrayList<>();
//		for (File file : foundFiles) {
//			System.out.println(file.getName());
//			travelTimes.addAll(calculateAvgTravelTime(file.getName()));
//		}
//
//		double avgTravelTime = 0;
//		for (Double travelTime : travelTimes) {
//			avgTravelTime += travelTime;
//
//		}
//
//		if (foundFiles.length == 0)
//			return;
//		else {
//
//			System.out.println("total experiments considered:" + foundFiles.length);
//			System.out.println("total ambulances considered:" + travelTimes.size());
//			avgTravelTime = avgTravelTime / travelTimes.size();
//			System.out.println("average travel time ambulance " + avgTravelTime);
//			System.out.println();
//
//			// two lane must be considered
//			ps.print(q * 2 + " ");
//			ps.println(avgTravelTime);
//		}
//
//	}

	public static void calculateStatistics(String files_start_with, int q, int lanes, PrintStream ps) {

		// project directory
		File dir = new File("C:\\Users\\midaab\\workspace-its\\MovsimYCalc");

		// travel time files
		File[] foundFiles = dir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.startsWith(files_start_with);
			}
		});

		// observer file
		File[] foundFilesObserver = dir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.startsWith("Observer " + files_start_with);
			}
		});

		// results travel time ambulances
		ArrayList<Double> travelTimesAMB = new ArrayList<>();
		for (File file : foundFiles) {
			System.out.println(file.getName());
			travelTimesAMB.addAll(calculateAvgTravelTime(file.getName(),"A"));
		}
		
		// results travel time cars
		ArrayList<Double> travelTimesCAR = new ArrayList<>();
		for (File file : foundFiles) {
			System.out.println(file.getName());
			travelTimesCAR.addAll(calculateAvgTravelTime(file.getName(),"C"));
		}

		// results observer
		ArrayList<Double> otherStatistics = new ArrayList<>();
		if (foundFilesObserver.length == 1)
			otherStatistics = extractObserverData(foundFilesObserver[0].getName());

		double avgTravelTimeAMB = 0;
		for (Double travelTime : travelTimesAMB) {
			avgTravelTimeAMB += travelTime;
		}
		
		double avgTravelTimeCAR = 0;
		for (Double travelTime : travelTimesCAR) {
			avgTravelTimeCAR+= travelTime;
		}

		if (foundFiles.length == 0)
			return;
		else {

			System.out.println("total experiments considered:" + foundFiles.length);
			System.out.println("total ambulances considered:" + travelTimesAMB.size());
			avgTravelTimeAMB = avgTravelTimeAMB / travelTimesAMB.size();
			System.out.println("average travel time ambulance " + avgTravelTimeAMB);
			avgTravelTimeCAR = avgTravelTimeCAR / travelTimesCAR.size();
			System.out.println("average travel time car " + avgTravelTimeCAR);
			System.out.println();

			// two lane must be considered, so q*2
			ps.print(q * lanes + " ");
			ps.print(avgTravelTimeAMB + " ");
			ps.print(avgTravelTimeCAR + " ");
			// If observer produced data for adaptation
			if (foundFilesObserver.length == 1) {
				ps.print(otherStatistics.get(0) + " ");
				ps.print(otherStatistics.get(1) + " ");
				ps.print(otherStatistics.get(2) + " ");
				ps.print(otherStatistics.get(3) + " ");
			}
			ps.println();

		}

	}

	public static ArrayList<Double> calculateAvgTravelTime(String fileName, String vehicle) {

		ArrayList<Double> ambulancesTravelTime = new ArrayList<>();

		try {

			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String str;
			String delims = ",";

			int count = 0;

			// store in array values
			while ((str = in.readLine()) != null) {

				String[] tokens = str.split(delims);

				count++;

				// jump first line = names
				if (count != 1) {
					double entryTime = Double.valueOf(tokens[0]);
					double exitTime = Double.valueOf(tokens[1]);
					double traveltime = Double.valueOf(tokens[2]);
					double meanSpeed = Double.valueOf(tokens[3]);
					double VehicleID = Double.valueOf(tokens[4]);
					String VehicleLabel = tokens[5];				
					
					if (VehicleLabel.startsWith(" "+vehicle)) {
						ambulancesTravelTime.add(traveltime);
					}
				}
			}
			in.close();
		}

		catch (IOException e) {
			System.err.println(e.getLocalizedMessage());
		}
		return ambulancesTravelTime;
	}

	public static ArrayList<Double> extractObserverData(String fileName) {

		ArrayList<Double> observerData = new ArrayList<>();

		try {

			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String str;
			String delims = " ";

			int count = 0;

			// store in array values
			while ((str = in.readLine()) != null) {

				String[] tokens = str.split(delims);

				count++;

				if (count > 1) {
					String name = String.valueOf(tokens[0]);
					double num = Double.valueOf(tokens[1]);
					observerData.add(num);
				}

			}
			in.close();
		}

		catch (IOException e) {
			System.err.println(e.getLocalizedMessage());
		}
		return observerData;
	}

}

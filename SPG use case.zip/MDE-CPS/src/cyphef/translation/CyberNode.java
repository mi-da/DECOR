package cyphef.translation;

import java.util.ArrayList;

public class CyberNode {
	


}

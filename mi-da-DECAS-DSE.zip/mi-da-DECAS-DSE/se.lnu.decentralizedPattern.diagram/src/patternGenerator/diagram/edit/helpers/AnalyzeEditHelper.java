package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class AnalyzeEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

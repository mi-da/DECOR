package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class ConcretePatternEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

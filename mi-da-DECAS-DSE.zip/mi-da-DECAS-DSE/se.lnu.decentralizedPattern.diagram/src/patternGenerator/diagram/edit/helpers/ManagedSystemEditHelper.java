package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class ManagedSystemEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class NodeEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

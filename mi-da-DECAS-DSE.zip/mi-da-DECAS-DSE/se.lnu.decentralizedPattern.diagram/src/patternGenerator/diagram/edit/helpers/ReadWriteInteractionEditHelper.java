package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class ReadWriteInteractionEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

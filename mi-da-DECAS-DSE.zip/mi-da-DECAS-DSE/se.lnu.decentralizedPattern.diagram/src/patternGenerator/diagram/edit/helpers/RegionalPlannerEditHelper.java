package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class RegionalPlannerEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

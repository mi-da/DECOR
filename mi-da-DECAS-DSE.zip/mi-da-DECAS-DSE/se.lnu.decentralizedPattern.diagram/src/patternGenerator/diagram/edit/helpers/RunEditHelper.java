package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class RunEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class SlaveEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

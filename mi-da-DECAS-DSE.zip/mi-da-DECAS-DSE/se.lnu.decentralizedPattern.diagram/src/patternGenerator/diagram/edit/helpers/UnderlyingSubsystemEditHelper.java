package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class UnderlyingSubsystemEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

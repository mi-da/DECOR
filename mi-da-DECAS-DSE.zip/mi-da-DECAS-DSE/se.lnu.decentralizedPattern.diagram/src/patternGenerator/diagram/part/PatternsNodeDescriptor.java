package patternGenerator.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class PatternsNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public PatternsNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}

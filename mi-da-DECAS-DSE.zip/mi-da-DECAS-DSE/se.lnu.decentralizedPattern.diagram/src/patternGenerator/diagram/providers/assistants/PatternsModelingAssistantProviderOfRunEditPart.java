package patternGenerator.diagram.providers.assistants;

/**
 * @generated
 */
public class PatternsModelingAssistantProviderOfRunEditPart
		extends patternGenerator.diagram.providers.PatternsModelingAssistantProvider {

}

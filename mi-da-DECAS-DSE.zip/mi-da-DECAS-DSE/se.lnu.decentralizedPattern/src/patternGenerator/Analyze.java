/**
 */
package patternGenerator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analyze</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see patternGenerator.PatternGeneratorPackage#getAnalyze()
 * @model
 * @generated
 */
public interface Analyze extends MapeComponent {
} // Analyze

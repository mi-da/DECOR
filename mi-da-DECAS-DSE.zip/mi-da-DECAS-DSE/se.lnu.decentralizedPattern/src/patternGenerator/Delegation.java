/**
 */
package patternGenerator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delegation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see patternGenerator.PatternGeneratorPackage#getDelegation()
 * @model
 * @generated
 */
public interface Delegation extends IntraComponentInteraction {
} // Delegation

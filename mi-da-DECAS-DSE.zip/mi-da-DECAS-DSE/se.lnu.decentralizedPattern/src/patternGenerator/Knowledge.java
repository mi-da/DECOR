/**
 */
package patternGenerator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Knowledge</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see patternGenerator.PatternGeneratorPackage#getKnowledge()
 * @model
 * @generated
 */
public interface Knowledge extends MapeComponent {
} // Knowledge

/**
 */
package patternGenerator.decentralizedPattern;

import patternGenerator.ManagingSystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see patternGenerator.decentralizedPattern.DecentralizedPatternPackage#getNode()
 * @model
 * @generated
 */
public interface Node extends ManagingSystem {
} // Node

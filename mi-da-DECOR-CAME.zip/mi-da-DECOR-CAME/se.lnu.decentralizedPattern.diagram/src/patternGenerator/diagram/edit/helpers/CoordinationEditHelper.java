package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class CoordinationEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

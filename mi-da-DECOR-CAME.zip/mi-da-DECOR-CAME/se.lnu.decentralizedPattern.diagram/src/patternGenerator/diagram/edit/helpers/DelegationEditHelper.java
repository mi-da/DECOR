package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class DelegationEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

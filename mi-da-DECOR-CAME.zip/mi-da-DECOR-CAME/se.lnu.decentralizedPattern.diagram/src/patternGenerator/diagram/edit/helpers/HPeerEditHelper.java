package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class HPeerEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

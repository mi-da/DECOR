package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class InterComponentInteractionEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

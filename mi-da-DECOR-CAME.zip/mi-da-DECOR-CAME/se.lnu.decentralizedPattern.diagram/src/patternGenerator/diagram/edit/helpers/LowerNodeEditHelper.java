package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class LowerNodeEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

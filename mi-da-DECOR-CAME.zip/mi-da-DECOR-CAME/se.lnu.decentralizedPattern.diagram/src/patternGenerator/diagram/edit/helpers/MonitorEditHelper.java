package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class MonitorEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

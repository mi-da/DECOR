package patternGenerator.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class PatternsBaseEditHelper extends GeneratedEditHelperBase {

}

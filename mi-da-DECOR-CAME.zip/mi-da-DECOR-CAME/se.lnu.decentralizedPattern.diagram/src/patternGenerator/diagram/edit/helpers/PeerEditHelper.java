package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class PeerEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

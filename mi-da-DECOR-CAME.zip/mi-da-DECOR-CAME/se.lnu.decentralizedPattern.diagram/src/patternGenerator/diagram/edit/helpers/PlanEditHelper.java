package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class PlanEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

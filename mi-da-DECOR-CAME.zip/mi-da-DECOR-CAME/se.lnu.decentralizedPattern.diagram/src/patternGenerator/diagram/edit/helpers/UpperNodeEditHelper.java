package patternGenerator.diagram.edit.helpers;

/**
 * @generated
 */
public class UpperNodeEditHelper extends patternGenerator.diagram.edit.helpers.PatternsBaseEditHelper {
}

package patternGenerator.diagram.part;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.gmf.tooling.runtime.actions.DefaultLoadResourceAction;

/**
 * @generated
 */
public class LoadResourceAction extends DefaultLoadResourceAction {
	/**
	* @generated
	*/
	public Object execute(ExecutionEvent event) throws ExecutionException {
		return super.execute(event);
	}

}

package patternGenerator.diagram.runtime;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;

public class MyRuntimeHandler extends org.eclipse.core.commands.AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		System.out.println("CIAONE");
		// TODO Auto-generated method stub
		return null;
	}

}

/**
 */
package patternGenerator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mape Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see patternGenerator.PatternGeneratorPackage#getMapeComponent()
 * @model abstract="true"
 * @generated
 */
public interface MapeComponent extends EObject {
} // MapeComponent

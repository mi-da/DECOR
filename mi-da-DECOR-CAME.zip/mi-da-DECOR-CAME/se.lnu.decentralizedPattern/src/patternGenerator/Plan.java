/**
 */
package patternGenerator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Plan</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see patternGenerator.PatternGeneratorPackage#getPlan()
 * @model
 * @generated
 */
public interface Plan extends MapeComponent {
} // Plan

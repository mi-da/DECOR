
package cyphef.generated.bus5;

import peersim.core.Node;
import peersim.edsim.EDProtocol;

public class Execute
    implements EDProtocol
{

    final static Long serialVersionUID = 1L;

    /**
     * Creates a new Execute.
     * 
     */
    public Execute() {
    }

    @Override
    public void processEvent(Node node, int pid, Object event) {
    }

    @Override
    public Object clone() {
        return this;
    }

}

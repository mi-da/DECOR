
package cyphef.generated.master;

import peersim.core.Node;
import peersim.edsim.EDProtocol;

public class Plan
    implements EDProtocol
{

    final static Long serialVersionUID = 1L;

    /**
     * Creates a new Plan.
     * 
     */
    public Plan() {
    }

    @Override
    public void processEvent(Node node, int pid, Object event) {
    }

    @Override
    public Object clone() {
        return this;
    }

}
